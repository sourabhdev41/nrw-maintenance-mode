/* NRW Maintenance Mode — Admin JS */
(function ($) {
  'use strict';

  /* ---- TABS ---- */
  $('.nrw-tab').on('click', function () {
    var tab = $(this).data('tab');
    $('.nrw-tab').removeClass('active');
    $(this).addClass('active');
    $('.nrw-panel').removeClass('active');
    $('#tab-' + tab).addClass('active');

    // Load preview iframe when switching to preview
    if (tab === 'preview') {
      loadPreviewFrame();
    }
  });

  /* ---- TOGGLE CARD live class ---- */
  $('#nrwEnabled').on('change', function () {
    if ($(this).is(':checked')) {
      $('#nrwToggleCard').addClass('is-on').find('h2').text('🚧 Maintenance Mode is Active');
      $('#nrwToggleCard').find('p').text('Visitors see your maintenance page. Admins bypass it.');
      $('.nrw-status-badge').removeClass('inactive').addClass('active').html('<span class="nrw-status-dot"></span> Maintenance ON');
    } else {
      $('#nrwToggleCard').removeClass('is-on').find('h2').text('✅ Your Site is Live');
      $('#nrwToggleCard').find('p').text('Toggle to put your site into maintenance mode.');
      $('.nrw-status-badge').removeClass('active').addClass('inactive').html('<span class="nrw-status-dot"></span> Site Live');
    }
  });

  /* ---- THEME SELECTION ---- */
  $('[name="theme"]').on('change', function () {
    $('.nrw-theme-card').removeClass('selected');
    $(this).closest('.nrw-theme-card').addClass('selected');
    updateMiniPreview();
  });

  /* ---- MODE SELECTION ---- */
  $('[name="mode"]').on('change', function () {
    $('.nrw-mode-option').removeClass('active');
    $(this).closest('.nrw-mode-option').addClass('active');
  });

  /* ---- COLOR SYNC ---- */
  function syncColor(colorId, textId) {
    $('#' + colorId).on('input', function () {
      $('#' + textId).val($(this).val());
      updateMiniPreview();
    });
    $('#' + textId).on('input', function () {
      var val = $(this).val();
      if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
        $('#' + colorId).val(val);
        updateMiniPreview();
      }
    });
  }
  syncColor('nrwBgColor', 'nrwBgColorText');
  syncColor('nrwAccentColor', 'nrwAccentColorText');
  syncColor('nrwTextColor', 'nrwTextColorText');

  /* ---- LIVE MINI PREVIEW ---- */
  function updateMiniPreview() {
    var bg     = $('#nrwBgColor').val();
    var accent = $('#nrwAccentColor').val();
    var txt    = $('#nrwTextColor').val();
    var h      = $('#nrwHeading').val() || 'We\'ll Be Back Soon!';
    var s      = $('#nrwSubtext').val() || 'We\'re doing some quick maintenance...';

    $('#mpBg').css('background', bg);
    $('#mpBlob1, #mpBlob2').css('background', accent);
    $('#mpFill').css('background', accent);
    $('#mpHeading').css('color', txt).text(h);
    $('#mpSub').css('color', txt).text(s);
  }

  $('#nrwHeading, #nrwSubtext').on('input', updateMiniPreview);
  updateMiniPreview();

  /* ---- SAVE SETTINGS ---- */
  $('#nrwSaveBtn').on('click', function () {
    var $btn = $(this).text('Saving…').prop('disabled', true);

    $.ajax({
      url: nrwMM.ajaxUrl,
      type: 'POST',
      data: {
        action:          'nrw_mm_save',
        nonce:           nrwMM.nonce,
        enabled:         $('#nrwEnabled').is(':checked') ? '1' : '0',
        mode:            $('[name="mode"]:checked').val(),
        theme:           $('[name="theme"]:checked').val(),
        heading:         $('#nrwHeading').val(),
        subtext:         $('#nrwSubtext').val(),
        bg_color:        $('#nrwBgColor').val(),
        accent_color:    $('#nrwAccentColor').val(),
        text_color:      $('#nrwTextColor').val(),
        allow_admins:    $('#nrwAllowAdmins').is(':checked') ? '1' : '0',
        show_countdown:  '',
        countdown_date:  '',
        custom_css:      $('#nrwCustomCSS').val(),
      },
      success: function (res) {
        if (res.success) {
          showSaveMsg('✓ Settings saved!', false);
        } else {
          showSaveMsg('⚠ Error saving settings.', true);
        }
      },
      error: function () { showSaveMsg('⚠ Request failed.', true); },
      complete: function () { $btn.text('Save Settings').prop('disabled', false); }
    });
  });

  function showSaveMsg(msg, isError) {
    var $el = $('#nrwSaveMsg').text(msg).removeClass('error show');
    if (isError) $el.addClass('error');
    $el.addClass('show');
    setTimeout(function () { $el.removeClass('show'); }, 3000);
  }

  /* ---- FILE UPLOAD ---- */
  var $dropZone = $('#nrwDropZone');

  $dropZone.on('click', function () { $('#nrwHtmlFile').trigger('click'); });

  $dropZone.on('dragover dragenter', function (e) {
    e.preventDefault(); e.stopPropagation();
    $(this).addClass('drag-over');
  });
  $dropZone.on('dragleave drop', function (e) {
    e.preventDefault();
    $(this).removeClass('drag-over');
  });
  $dropZone.on('drop', function (e) {
    var file = e.originalEvent.dataTransfer.files[0];
    if (file) uploadHTML(file);
  });

  $('#nrwHtmlFile').on('change', function () {
    var file = this.files[0];
    if (file) uploadHTML(file);
  });

  function uploadHTML(file) {
    var $status = $('#nrwUploadStatus');
    var ext = file.name.split('.').pop().toLowerCase();
    if (ext !== 'html' && ext !== 'htm') {
      $status.text('⚠ Only .html and .htm files allowed.').addClass('error').removeClass('success').show();
      return;
    }

    var formData = new FormData();
    formData.append('action', 'nrw_mm_upload_html');
    formData.append('nonce', nrwMM.nonce);
    formData.append('html_file', file);

    $dropZone.find('.nrw-upload-title').text('Uploading…');

    $.ajax({
      url:         nrwMM.ajaxUrl,
      type:        'POST',
      data:        formData,
      processData: false,
      contentType: false,
      success: function (res) {
        if (res.success) {
          $status.text('✓ ' + res.data.message).addClass('success').removeClass('error').show();
          $dropZone.find('.nrw-upload-title').text(res.data.filename + ' uploaded!');
        } else {
          $status.text('⚠ ' + res.data.message).addClass('error').removeClass('success').show();
          $dropZone.find('.nrw-upload-title').text('Drag & drop your HTML file here');
        }
      },
      error: function () {
        $status.text('⚠ Upload failed.').addClass('error').removeClass('success').show();
        $dropZone.find('.nrw-upload-title').text('Drag & drop your HTML file here');
      }
    });
  }

  /* ---- PREVIEW ---- */
  function buildPreviewHTML() {
    var bg    = $('#nrwBgColor').val();
    var ac    = $('#nrwAccentColor').val();
    var tx    = $('#nrwTextColor').val();
    var h     = $('#nrwHeading').val() || "We'll Be Back Soon!";
    var s     = $('#nrwSubtext').val() || "We're doing some quick maintenance...";
    var theme = $('[name="theme"]:checked').val() || 'modern';
    return getPreviewHTML(theme, bg, ac, tx, h, s);
  }

  // Open Full Preview opens a real new browser tab
  $('#nrwOpenPreview').on('click', function (e) {
    e.preventDefault();
    var html = buildPreviewHTML();
    var blob = new Blob([html], { type: 'text/html' });
    var url  = URL.createObjectURL(blob);
    var win  = window.open(url, '_blank');
    if (!win) { loadPreviewFrame(); } // fallback if popup blocked
  });

  function loadPreviewFrame() {
    var html = buildPreviewHTML();
    var blob = new Blob([html], { type: 'text/html' });
    var url  = URL.createObjectURL(blob);
    $('#nrwPreviewFrame').attr('src', url);
  }

  function getPreviewHTML(theme, bg, accent, txt, heading, subtext) {
    if (theme === 'minimal') {
      return '<!DOCTYPE html><html><head><meta charset="UTF-8">' +
        '<style>@import url(\'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400&display=swap\');' +
        '*{box-sizing:border-box;margin:0;padding:0}' +
        'body{background:' + bg + ';color:' + txt + ';font-family:Lato,sans-serif;min-height:100vh;display:grid;grid-template-rows:1fr auto}' +
        'main{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;padding:80px;max-width:700px}' +
        '.label{font-size:11px;letter-spacing:.3em;text-transform:uppercase;color:' + accent + ';margin-bottom:32px}' +
        'h1{font-family:"Playfair Display",serif;font-size:clamp(2.4rem,5vw,4rem);font-weight:700;margin-bottom:28px}' +
        'p{font-size:1.05rem;line-height:1.8;opacity:.6;font-weight:300}' +
        '.line{width:48px;height:3px;background:' + accent + ';margin-top:48px}' +
        'footer{padding:24px 80px;border-top:1px solid rgba(0,0,0,0.08);font-size:12px;opacity:.4}' +
        '</style></head><body>' +
        '<main><span class="label">⚙ Under Maintenance</span>' +
        '<h1>' + heading + '</h1><p>' + subtext + '</p><div class="line"></div></main>' +
        '<footer>We\'ll be right back — thank you for your patience.</footer></body></html>';
    }
    if (theme === 'bold') {
      return '<!DOCTYPE html><html><head><meta charset="UTF-8">' +
        '<style>@import url(\'https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap\');' +
        '*{box-sizing:border-box;margin:0;padding:0}' +
        'body{background:' + bg + ';color:' + txt + ';font-family:"Space Mono",monospace;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px;position:relative;overflow:hidden}' +
        '.grid-bg{position:fixed;inset:0;background-image:linear-gradient(rgba(0,0,0,0.05) 1px,transparent 1px),linear-gradient(90deg,rgba(0,0,0,0.05) 1px,transparent 1px);background-size:48px 48px}' +
        '.tag{background:' + accent + ';color:#fff;padding:6px 16px;border-radius:4px;font-size:12px;letter-spacing:.2em;margin-bottom:40px;position:relative;z-index:2}' +
        'h1{font-size:clamp(2rem,7vw,5rem);font-weight:700;text-align:center;line-height:1;letter-spacing:-0.03em;position:relative;z-index:2;margin-bottom:28px}' +
        'h1 span{color:' + accent + '}' +
        'p{font-size:1rem;line-height:1.7;opacity:.6;max-width:440px;text-align:center;position:relative;z-index:2}' +
        '.dots{display:flex;gap:10px;margin-top:48px;position:relative;z-index:2}' +
        '.dot{width:10px;height:10px;border-radius:50%;background:' + accent + '}' +
        '</style></head><body><div class="grid-bg"></div>' +
        '<div class="tag">// MAINTENANCE IN PROGRESS</div>' +
        '<h1>' + heading + '<span>_</span></h1><p>' + subtext + '</p>' +
        '<div class="dots"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>' +
        '</body></html>';
    }
    // Modern (default)
    return '<!DOCTYPE html><html><head><meta charset="UTF-8">' +
      '<style>@import url(\'https://fonts.googleapis.com/css2?family=Syne:wght@800&family=DM+Sans:wght@400&display=swap\');' +
      '*{box-sizing:border-box;margin:0;padding:0}' +
      'body{background:' + bg + ';color:' + txt + ';font-family:"DM Sans",sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;overflow:hidden}' +
      '.blob{position:fixed;border-radius:50%;filter:blur(80px);opacity:.18;pointer-events:none}' +
      '.b1{width:500px;height:500px;background:' + accent + ';top:-100px;left:-100px}' +
      '.b2{width:400px;height:400px;background:' + accent + ';bottom:-80px;right:-80px}' +
      '.card{position:relative;z-index:10;text-align:center;padding:64px 48px;max-width:600px;width:90%}' +
      '.icon{width:72px;height:72px;background:' + accent + ';border-radius:24px;display:flex;align-items:center;justify-content:center;margin:0 auto 36px;font-size:32px}' +
      'h1{font-family:Syne,sans-serif;font-size:clamp(2rem,5vw,3.2rem);font-weight:800;margin-bottom:20px;letter-spacing:-0.02em}' +
      'p{font-size:1.1rem;line-height:1.7;opacity:.7;max-width:420px;margin:0 auto}' +
      '.bar{background:rgba(0,0,0,0.08);border-radius:100px;height:6px;overflow:hidden;margin-top:48px}' +
      '.fill{height:100%;background:' + accent + ';border-radius:100px;width:70%}' +
      '</style></head><body>' +
      '<div class="blob b1"></div><div class="blob b2"></div>' +
      '<div class="card"><div class="icon">🔧</div>' +
      '<h1>' + heading + '</h1><p>' + subtext + '</p>' +
      '<div class="bar"><div class="fill"></div></div></div>' +
      '</body></html>';
  }

}(jQuery));

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $heading; ?></title>
<meta name="robots" content="noindex, nofollow">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Work+Sans:wght@300;400;600&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root { --bg: <?php echo $bg; ?>; --accent: <?php echo $accent; ?>; --txt: <?php echo $txtcol; ?>; }

  body {
    background: var(--bg);
    color: var(--txt);
    font-family: 'Work Sans', sans-serif;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 40px;
    position: relative;
    overflow: hidden;
  }

  .grid-bg {
    position: fixed; inset: 0;
    background-image:
      linear-gradient(color-mix(in srgb, var(--txt) 5%, transparent) 1px, transparent 1px),
      linear-gradient(90deg, color-mix(in srgb, var(--txt) 5%, transparent) 1px, transparent 1px);
    background-size: 48px 48px;
  }

  .tag {
    font-family: 'Space Mono', monospace;
    font-size: 12px;
    letter-spacing: 0.2em;
    background: var(--accent);
    color: #fff;
    padding: 6px 16px;
    border-radius: 4px;
    margin-bottom: 40px;
    position: relative; z-index: 2;
  }

  h1 {
    font-family: 'Space Mono', monospace;
    font-size: clamp(2rem, 7vw, 5rem);
    font-weight: 700;
    text-align: center;
    line-height: 1.0;
    letter-spacing: -0.03em;
    position: relative; z-index: 2;
    margin-bottom: 28px;
  }

  h1 span {
    color: var(--accent);
    display: block;
  }

  p {
    font-size: 1rem;
    line-height: 1.7;
    opacity: 0.6;
    max-width: 440px;
    text-align: center;
    position: relative; z-index: 2;
  }

  .dots {
    display: flex; gap: 10px;
    margin-top: 48px;
    position: relative; z-index: 2;
  }

  .dot {
    width: 10px; height: 10px;
    border-radius: 50%;
    background: var(--accent);
    animation: blink 1.4s ease-in-out infinite;
  }
  .dot:nth-child(2) { animation-delay: 0.2s; opacity: 0.6; }
  .dot:nth-child(3) { animation-delay: 0.4s; opacity: 0.3; }

  @keyframes blink { 0%,80%,100% { transform: scale(1); } 40% { transform: scale(1.5); } }

  <?php if ( ! empty( $css ) ) echo $css; ?>
</style>
</head>
<body>
  <div class="grid-bg"></div>
  <div class="tag">// MAINTENANCE IN PROGRESS</div>
  <h1><?php echo $heading; ?><span>_</span></h1>
  <p><?php echo $subtext; ?></p>
  <div class="dots">
    <div class="dot"></div>
    <div class="dot"></div>
    <div class="dot"></div>
  </div>
</body>
</html>

<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="nrw-wrap">

  <!-- HEADER -->
  <div class="nrw-header">
    <div class="nrw-header-inner">
      <div class="nrw-logo">
        <span class="nrw-logo-icon">🔧</span>
        <div>
          <div class="nrw-logo-name">NRW Maintenance Mode</div>
          <div class="nrw-logo-by">by <a href="https://wp.nrwone.in" target="_blank">NRW One</a></div>
        </div>
      </div>
      <div class="nrw-status-badge <?php echo $s['enabled'] ? 'active' : 'inactive'; ?>">
        <span class="nrw-status-dot"></span>
        <?php echo $s['enabled'] ? 'Maintenance ON' : 'Site Live'; ?>
      </div>
    </div>
  </div>

  <div class="nrw-body">

    <!-- TOGGLE HERO -->
    <div class="nrw-toggle-card <?php echo $s['enabled'] ? 'is-on' : ''; ?>" id="nrwToggleCard">
      <div class="nrw-toggle-info">
        <h2><?php echo $s['enabled'] ? '🚧 Maintenance Mode is Active' : '✅ Your Site is Live'; ?></h2>
        <p><?php echo $s['enabled'] ? 'Visitors see your maintenance page. Admins bypass it.' : 'Toggle to put your site into maintenance mode.'; ?></p>
      </div>
      <label class="nrw-big-toggle">
        <input type="checkbox" id="nrwEnabled" <?php checked( $s['enabled'], 1 ); ?>>
        <span class="nrw-toggle-track">
          <span class="nrw-toggle-thumb"></span>
        </span>
      </label>
    </div>

    <!-- TABS -->
    <div class="nrw-tabs">
      <button class="nrw-tab active" data-tab="design">🎨 Design</button>
      <button class="nrw-tab" data-tab="custom">📄 Custom HTML</button>
      <button class="nrw-tab" data-tab="settings">⚙ Settings</button>
      <button class="nrw-tab" data-tab="preview">👁 Preview</button>
      <button class="nrw-tab" data-tab="donate">💛 Support Us</button>
    </div>

    <!-- =================== TAB: DESIGN =================== -->
    <div class="nrw-panel active" id="tab-design">
      <div class="nrw-grid-2">

        <!-- Left: Controls -->
        <div class="nrw-card">
          <h3 class="nrw-card-title">Choose a Theme</h3>
          <div class="nrw-theme-grid">
            <?php
            $themes = [
              'modern'  => [ 'name' => 'Modern', 'icon' => '✨', 'desc' => 'Floating blobs & animated card' ],
              'minimal' => [ 'name' => 'Minimal', 'icon' => '🤍', 'desc' => 'Editorial serif, left-aligned' ],
              'bold'    => [ 'name' => 'Bold',    'icon' => '⚡', 'desc' => 'Grid-bg, mono font, strong type' ],
            ];
            foreach ( $themes as $key => $theme ) :
              $active = $s['theme'] === $key ? 'selected' : '';
            ?>
            <label class="nrw-theme-card <?php echo $active; ?>">
              <input type="radio" name="theme" value="<?php echo $key; ?>" <?php checked( $s['theme'], $key ); ?> class="nrw-theme-radio">
              <div class="nrw-theme-icon"><?php echo $theme['icon']; ?></div>
              <div class="nrw-theme-name"><?php echo $theme['name']; ?></div>
              <div class="nrw-theme-desc"><?php echo $theme['desc']; ?></div>
            </label>
            <?php endforeach; ?>
          </div>

          <div class="nrw-field-group">
            <label class="nrw-label">Heading Text</label>
            <input type="text" id="nrwHeading" class="nrw-input" value="<?php echo esc_attr( $s['heading'] ); ?>" placeholder="We'll Be Back Soon!">
          </div>

          <div class="nrw-field-group">
            <label class="nrw-label">Subtext</label>
            <textarea id="nrwSubtext" class="nrw-input nrw-textarea" placeholder="We're doing some quick maintenance..."><?php echo esc_textarea( $s['subtext'] ); ?></textarea>
          </div>

          <div class="nrw-color-row">
            <div class="nrw-field-group">
              <label class="nrw-label">Background Color</label>
              <div class="nrw-color-wrap">
                <input type="color" id="nrwBgColor" value="<?php echo esc_attr( $s['bg_color'] ); ?>" class="nrw-color">
                <input type="text" id="nrwBgColorText" value="<?php echo esc_attr( $s['bg_color'] ); ?>" class="nrw-input nrw-color-text">
              </div>
            </div>
            <div class="nrw-field-group">
              <label class="nrw-label">Accent Color</label>
              <div class="nrw-color-wrap">
                <input type="color" id="nrwAccentColor" value="<?php echo esc_attr( $s['accent_color'] ); ?>" class="nrw-color">
                <input type="text" id="nrwAccentColorText" value="<?php echo esc_attr( $s['accent_color'] ); ?>" class="nrw-input nrw-color-text">
              </div>
            </div>
            <div class="nrw-field-group">
              <label class="nrw-label">Text Color</label>
              <div class="nrw-color-wrap">
                <input type="color" id="nrwTextColor" value="<?php echo esc_attr( $s['text_color'] ); ?>" class="nrw-color">
                <input type="text" id="nrwTextColorText" value="<?php echo esc_attr( $s['text_color'] ); ?>" class="nrw-input nrw-color-text">
              </div>
            </div>
          </div>

          <div class="nrw-field-group">
            <label class="nrw-label">Custom CSS (optional)</label>
            <textarea id="nrwCustomCSS" class="nrw-input nrw-textarea nrw-code" placeholder="/* Add extra styles here */"><?php echo esc_textarea( $s['custom_css'] ); ?></textarea>
          </div>

        </div>

        <!-- Right: Live Mini Preview -->
        <div class="nrw-card nrw-preview-sidebar">
          <h3 class="nrw-card-title">Live Preview</h3>
          <div class="nrw-mini-preview" id="nrwMiniPreview">
            <div class="mp-bg" id="mpBg">
              <div class="mp-blob mp-b1" id="mpBlob1"></div>
              <div class="mp-blob mp-b2" id="mpBlob2"></div>
              <div class="mp-card" id="mpCard">
                <div class="mp-icon" id="mpIcon">🔧</div>
                <div class="mp-heading" id="mpHeading"><?php echo esc_html( $s['heading'] ); ?></div>
                <div class="mp-sub" id="mpSub"><?php echo esc_html( $s['subtext'] ); ?></div>
                <div class="mp-bar"><div class="mp-fill" id="mpFill"></div></div>
              </div>
            </div>
          </div>
          <div class="nrw-preview-note">Updates live as you type ↑</div>
        </div>

      </div>
    </div>

    <!-- =================== TAB: CUSTOM HTML =================== -->
    <div class="nrw-panel" id="tab-custom">
      <div class="nrw-card">
        <h3 class="nrw-card-title">Upload Your Own Maintenance Page</h3>
        <p class="nrw-muted">Upload a custom <code>.html</code> file — it will be served as-is to visitors. Your file can include embedded CSS, JavaScript, and images (use absolute URLs for external assets).</p>

        <div class="nrw-mode-switch">
          <label class="nrw-mode-option <?php echo $s['mode'] === 'default' ? 'active' : ''; ?>">
            <input type="radio" name="mode" value="default" <?php checked( $s['mode'], 'default' ); ?>>
            <span class="nrw-mode-icon">🎨</span>
            <span>Use Default Theme</span>
          </label>
          <label class="nrw-mode-option <?php echo $s['mode'] === 'custom_html' ? 'active' : ''; ?>">
            <input type="radio" name="mode" value="custom_html" <?php checked( $s['mode'], 'custom_html' ); ?>>
            <span class="nrw-mode-icon">📄</span>
            <span>Use Custom HTML</span>
          </label>
        </div>

        <div class="nrw-upload-zone" id="nrwDropZone">
          <div class="nrw-upload-icon">📁</div>
          <div class="nrw-upload-title">Drag & drop your HTML file here</div>
          <div class="nrw-upload-sub">or</div>
          <label class="nrw-btn nrw-btn-outline" for="nrwHtmlFile">Browse File</label>
          <input type="file" id="nrwHtmlFile" accept=".html,.htm" style="display:none">
        </div>

        <?php if ( ! empty( $s['custom_html_file'] ) ) : ?>
        <div class="nrw-file-badge">
          <span>📄</span>
          <span><?php echo esc_html( $s['custom_html_file'] ); ?></span>
          <span class="nrw-file-ok">✓ Active</span>
        </div>
        <?php endif; ?>

        <div id="nrwUploadStatus" class="nrw-notice" style="display:none"></div>
      </div>
    </div>

    <!-- =================== TAB: SETTINGS =================== -->
    <div class="nrw-panel" id="tab-settings">
      <div class="nrw-card">
        <h3 class="nrw-card-title">General Settings</h3>

        <div class="nrw-toggle-row">
          <div>
            <div class="nrw-toggle-label">Admins can see the site</div>
            <div class="nrw-toggle-desc">Logged-in administrators bypass maintenance mode and see the live site.</div>
          </div>
          <label class="nrw-switch">
            <input type="checkbox" id="nrwAllowAdmins" <?php checked( $s['allow_admins'], 1 ); ?>>
            <span class="nrw-switch-track"></span>
          </label>
        </div>

        <hr class="nrw-hr">

        <div class="nrw-seo-info">
          <div class="nrw-seo-icon">🛡</div>
          <div>
            <strong>SEO Protected</strong>
            <p>This plugin sends a proper <code>503 Service Unavailable</code> + <code>Retry-After: 3600</code> header and <code>noindex, nofollow</code> meta — so search engines know your site is temporarily down and won't penalize your rankings.</p>
          </div>
        </div>

        <div class="nrw-seo-info">
          <div class="nrw-seo-icon">🔌</div>
          <div>
            <strong>Plugin Safe</strong>
            <p>Maintenance mode is handled via WordPress's <code>template_redirect</code> hook — no core files are modified, and all other plugins continue to work normally behind the scenes.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- =================== TAB: PREVIEW =================== -->
    <div class="nrw-panel" id="tab-preview">
      <div class="nrw-card">
        <h3 class="nrw-card-title">Full Page Preview</h3>
        <p class="nrw-muted">Save your settings first, then click Preview to see exactly what visitors will see.</p>
        <div class="nrw-preview-bar">
          <button class="nrw-btn nrw-btn-primary" id="nrwOpenPreview">Open Full Preview ↗</button>
          <span class="nrw-muted" style="font-size:13px">Opens in a new tab</span>
        </div>
        <iframe id="nrwPreviewFrame" class="nrw-preview-frame" src="about:blank"></iframe>
      </div>
    </div>

    <!-- =================== TAB: DONATE =================== -->
    <div class="nrw-panel" id="tab-donate">
      <div class="nrw-card nrw-donate-card">

        <div class="nrw-donate-top">
          <div class="nrw-donate-emoji">💛</div>
          <h2>Want to Help? You Have Two Ways.</h2>
          <p class="nrw-donate-lead">NRW India helps underprivileged students get the basic school supplies they need — things like notebooks, pens, bags, and geometry sets that many families can't afford.</p>
        </div>

        <hr class="nrw-hr">

        <div class="nrw-two-ways">

          <div class="nrw-way nrw-way-personal">
            <div class="nrw-way-icon">🤝</div>
            <div class="nrw-way-label">The Better Way</div>
            <h3>Do It Yourself — In Person</h3>
            <p>If there's a student near you who needs help, just go and give it to them directly. Buy them what they need from the list below. No apps, no middlemen — just you and a kid who now has what they need to go to school.</p>
            <p class="nrw-way-note">This is the most impactful thing you can do. Seriously.</p>
            <div class="nrw-donate-items nrw-items-inline">
              <div class="nrw-item">📓 Notebooks</div>
              <div class="nrw-item">✏️ Pens &amp; Pencils</div>
              <div class="nrw-item">📐 Geometry Set</div>
              <div class="nrw-item">🎒 School Bag</div>
              <div class="nrw-item">📏 Ruler &amp; Eraser</div>
              <div class="nrw-item">🖍️ Crayons &amp; Colors</div>
              <div class="nrw-item">📒 Drawing Book</div>
              <div class="nrw-item">✂️ Scissors &amp; Glue</div>
            </div>
          </div>

          <div class="nrw-way-divider">or</div>

          <div class="nrw-way nrw-way-donate">
            <div class="nrw-way-icon">💛</div>
            <div class="nrw-way-label">The Easy Way</div>
            <h3>Donate Online</h3>
            <p>Can't do it in person? A small online donation lets NRW India buy these supplies and deliver them to students who need them.</p>
            <p class="nrw-way-note">Every rupee goes directly to supplies. No overhead.</p>
            <a href="https://nrw.org.in" target="_blank" class="nrw-btn nrw-btn-donate">
              💛 Donate at nrw.org.in
            </a>
          </div>

        </div>

        <p class="nrw-donate-footer">Whether you donate or walk up to a kid and hand them a notebook — both matter. Pick what works for you. Thank you for caring. 🙏</p>
      </div>
    </div>

  </div><!-- .nrw-body -->

  <!-- SAVE FOOTER -->
  <div class="nrw-save-bar">
    <div class="nrw-save-inner">
      <div id="nrwSaveMsg" class="nrw-save-msg"></div>
      <button class="nrw-btn nrw-btn-primary" id="nrwSaveBtn">Save Settings</button>
    </div>
  </div>

</div><!-- .nrw-wrap -->

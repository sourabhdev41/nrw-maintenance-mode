<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $heading; ?></title>
<meta name="robots" content="noindex, nofollow">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Lato:wght@300;400&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root { --bg: <?php echo $bg; ?>; --accent: <?php echo $accent; ?>; --txt: <?php echo $txtcol; ?>; }

  body {
    background: var(--bg);
    color: var(--txt);
    font-family: 'Lato', sans-serif;
    min-height: 100vh;
    display: grid;
    grid-template-rows: 1fr auto;
  }

  main {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    padding: 80px;
    max-width: 700px;
  }

  .label {
    font-size: 11px;
    letter-spacing: 0.3em;
    text-transform: uppercase;
    color: var(--accent);
    font-weight: 400;
    margin-bottom: 32px;
  }

  h1 {
    font-family: 'Playfair Display', serif;
    font-size: clamp(2.4rem, 5vw, 4rem);
    font-weight: 700;
    line-height: 1.15;
    margin-bottom: 28px;
    letter-spacing: -0.01em;
  }

  p {
    font-size: 1.05rem;
    line-height: 1.8;
    opacity: 0.6;
    font-weight: 300;
    max-width: 380px;
  }

  .line {
    width: 48px;
    height: 3px;
    background: var(--accent);
    margin-top: 48px;
    animation: grow 1.5s ease forwards;
    transform-origin: left;
  }
  @keyframes grow { from { transform: scaleX(0); } to { transform: scaleX(1); } }

  footer {
    padding: 24px 80px;
    border-top: 1px solid color-mix(in srgb, var(--txt) 10%, transparent);
    font-size: 12px;
    opacity: 0.4;
    letter-spacing: 0.05em;
  }

  @media (max-width: 600px) { main, footer { padding-left: 32px; padding-right: 32px; } }

  <?php if ( ! empty( $css ) ) echo $css; ?>
</style>
</head>
<body>
  <main>
    <span class="label">⚙ Under Maintenance</span>
    <h1><?php echo $heading; ?></h1>
    <p><?php echo $subtext; ?></p>
    <div class="line"></div>
  </main>
  <footer>We'll be right back — thank you for your patience.</footer>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $heading; ?></title>
<meta name="robots" content="noindex, nofollow">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: <?php echo $bg; ?>;
    --accent: <?php echo $accent; ?>;
    --txt: <?php echo $txtcol; ?>;
  }

  body {
    background: var(--bg);
    color: var(--txt);
    font-family: 'DM Sans', sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }

  .blob {
    position: fixed;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.18;
    pointer-events: none;
    animation: drift 12s ease-in-out infinite alternate;
  }
  .blob-1 { width: 500px; height: 500px; background: var(--accent); top: -100px; left: -100px; }
  .blob-2 { width: 400px; height: 400px; background: var(--accent); bottom: -80px; right: -80px; animation-delay: -6s; }

  @keyframes drift { from { transform: translate(0,0) scale(1); } to { transform: translate(40px,30px) scale(1.08); } }

  .card {
    position: relative;
    z-index: 10;
    text-align: center;
    padding: 64px 48px;
    max-width: 600px;
    width: 90%;
  }

  .icon {
    width: 72px; height: 72px;
    background: var(--accent);
    border-radius: 24px;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 36px;
    font-size: 32px;
    box-shadow: 0 16px 40px color-mix(in srgb, var(--accent) 40%, transparent);
    animation: pulse 3s ease-in-out infinite;
  }

  @keyframes pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.06); } }

  h1 {
    font-family: 'Syne', sans-serif;
    font-size: clamp(2rem, 5vw, 3.2rem);
    font-weight: 800;
    line-height: 1.1;
    margin-bottom: 20px;
    letter-spacing: -0.02em;
  }

  p {
    font-size: 1.1rem;
    line-height: 1.7;
    opacity: 0.7;
    max-width: 420px;
    margin: 0 auto;
  }

  .bar-wrap {
    margin-top: 48px;
    background: color-mix(in srgb, var(--txt) 10%, transparent);
    border-radius: 100px;
    height: 6px;
    overflow: hidden;
  }
  .bar-fill {
    height: 100%;
    background: var(--accent);
    border-radius: 100px;
    width: 0;
    animation: load 3.5s ease forwards;
  }
  @keyframes load { to { width: 70%; } }

  <?php if ( ! empty( $css ) ) echo $css; ?>
</style>
</head>
<body>
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>
  <div class="card">
    <div class="icon">🔧</div>
    <h1><?php echo $heading; ?></h1>
    <p><?php echo $subtext; ?></p>
    <div class="bar-wrap"><div class="bar-fill"></div></div>
  </div>
</body>
</html>

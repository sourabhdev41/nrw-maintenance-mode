<?php
/**
 * Plugin Name: NRW Maintenance Mode
 * Plugin URI:  https://wp.nrwone.in
 * Description: A beautiful, SEO-safe maintenance mode plugin with custom HTML upload and multiple default themes.
 * Version:     1.0.0
 * Author:      NRW One
 * Author URI:  https://wp.nrwone.in
 * License:     GPL-2.0+
 * Text Domain: nrw-maintenance-mode
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'NRW_MM_VERSION', '1.0.0' );
define( 'NRW_MM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'NRW_MM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'NRW_MM_UPLOAD_DIR', wp_upload_dir()['basedir'] . '/nrw-maintenance/' );
define( 'NRW_MM_UPLOAD_URL', wp_upload_dir()['baseurl'] . '/nrw-maintenance/' );

/* ============================================================
   ACTIVATION / DEACTIVATION
   ============================================================ */

register_activation_hook( __FILE__, 'nrw_mm_activate' );
register_deactivation_hook( __FILE__, 'nrw_mm_deactivate' );

function nrw_mm_activate() {
    if ( ! get_option( 'nrw_mm_settings' ) ) {
        update_option( 'nrw_mm_settings', nrw_mm_default_settings() );
    }
    if ( ! file_exists( NRW_MM_UPLOAD_DIR ) ) {
        wp_mkdir_p( NRW_MM_UPLOAD_DIR );
    }
}

function nrw_mm_deactivate() {
    // Nothing destructive — settings preserved intentionally
}

function nrw_mm_default_settings() {
    return [
        'enabled'          => 0,
        'mode'             => 'default',        // default | custom_html
        'theme'            => 'modern',         // modern | minimal | bold
        'heading'          => 'We\'ll Be Back Soon!',
        'subtext'          => 'We\'re doing some quick maintenance. Thanks for your patience!',
        'bg_color'         => '#f5f0eb',
        'accent_color'     => '#2a9d8f',
        'text_color'       => '#1a1a1a',
        'show_countdown'   => 0,
        'countdown_date'   => '',
        'custom_html_file' => '',
        'allow_admins'     => 1,
        'custom_css'       => '',
    ];
}

/* ============================================================
   FRONTEND INTERCEPTION — SEO SAFE (503 for bots, bypass for admins)
   ============================================================ */

add_action( 'template_redirect', 'nrw_mm_intercept', 1 );

function nrw_mm_intercept() {
    $settings = nrw_mm_get_settings();

    if ( ! $settings['enabled'] ) return;

    // Always allow WP login, admin AJAX, REST, cron
    if ( is_admin() ) return;
    if ( defined( 'DOING_CRON' ) && DOING_CRON ) return;
    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;
    if ( strpos( $_SERVER['REQUEST_URI'], '/wp-login.php' ) !== false ) return;
    if ( strpos( $_SERVER['REQUEST_URI'], '/wp-admin/' ) !== false ) return;

    // Bypass logged-in admins if setting enabled
    if ( $settings['allow_admins'] && current_user_can( 'manage_options' ) ) return;

    // Send proper 503 so search engines don't index maintenance page
    header( 'HTTP/1.1 503 Service Unavailable' );
    header( 'Retry-After: 3600' );
    header( 'Content-Type: text/html; charset=utf-8' );
    // Prevent browsers from caching the maintenance page
    header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
    header( 'Cache-Control: post-check=0, pre-check=0', false );
    header( 'Pragma: no-cache' );

    nrw_mm_render_page( $settings );
    exit;
}

function nrw_mm_get_settings() {
    $defaults = nrw_mm_default_settings();
    $saved    = get_option( 'nrw_mm_settings', [] );
    return wp_parse_args( $saved, $defaults );
}

/* ============================================================
   RENDER MAINTENANCE PAGE
   ============================================================ */

function nrw_mm_render_page( $s ) {
    // Custom HTML mode
    if ( $s['mode'] === 'custom_html' && ! empty( $s['custom_html_file'] ) ) {
        $file = NRW_MM_UPLOAD_DIR . basename( $s['custom_html_file'] );
        if ( file_exists( $file ) ) {
            readfile( $file );
            return;
        }
    }

    // Default themed page
    $heading  = esc_html( $s['heading'] );
    $subtext  = esc_html( $s['subtext'] );
    $bg       = esc_attr( $s['bg_color'] );
    $accent   = esc_attr( $s['accent_color'] );
    $txtcol   = esc_attr( $s['text_color'] );
    $theme    = $s['theme'];
    $css      = $s['custom_css'];

    include NRW_MM_PLUGIN_DIR . 'templates/maintenance-' . sanitize_key( $theme ) . '.php';
}

/* ============================================================
   ADMIN MENU
   ============================================================ */

add_action( 'admin_menu', 'nrw_mm_admin_menu' );

function nrw_mm_admin_menu() {
    add_menu_page(
        'NRW Maintenance Mode',
        'Maintenance Mode',
        'manage_options',
        'nrw-maintenance-mode',
        'nrw_mm_admin_page',
        'dashicons-hammer',
        80
    );
}

/* ============================================================
   ADMIN STYLES & SCRIPTS
   ============================================================ */

add_action( 'admin_enqueue_scripts', 'nrw_mm_admin_assets' );

function nrw_mm_admin_assets( $hook ) {
    if ( $hook !== 'toplevel_page_nrw-maintenance-mode' ) return;
    wp_enqueue_style( 'nrw-mm-admin', NRW_MM_PLUGIN_URL . 'assets/admin.css', [], NRW_MM_VERSION );
    wp_enqueue_script( 'nrw-mm-admin', NRW_MM_PLUGIN_URL . 'assets/admin.js', [ 'jquery' ], NRW_MM_VERSION, true );
    wp_localize_script( 'nrw-mm-admin', 'nrwMM', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'nrw_mm_nonce' ),
    ] );
}

/* ============================================================
   SAVE SETTINGS (AJAX)
   ============================================================ */

add_action( 'wp_ajax_nrw_mm_save', 'nrw_mm_ajax_save' );

function nrw_mm_ajax_save() {
    check_ajax_referer( 'nrw_mm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

    $settings = nrw_mm_get_settings();

    // Checkbox: explicitly sent as '1' when on, '0' when off — never rely on isset() alone
    $settings['enabled']        = ( isset( $_POST['enabled'] ) && $_POST['enabled'] == '1' ) ? 1 : 0;
    $settings['mode']           = sanitize_key( $_POST['mode'] ?? 'default' );
    $settings['theme']          = sanitize_key( $_POST['theme'] ?? 'modern' );
    $settings['heading']        = sanitize_text_field( $_POST['heading'] ?? '' );
    $settings['subtext']        = sanitize_textarea_field( $_POST['subtext'] ?? '' );
    $settings['bg_color']       = sanitize_hex_color( $_POST['bg_color'] ?? '#f5f0eb' );
    $settings['accent_color']   = sanitize_hex_color( $_POST['accent_color'] ?? '#2a9d8f' );
    $settings['text_color']     = sanitize_hex_color( $_POST['text_color'] ?? '#1a1a1a' );
    $settings['allow_admins']   = ( isset( $_POST['allow_admins'] ) && $_POST['allow_admins'] == '1' ) ? 1 : 0;
    $settings['show_countdown'] = isset( $_POST['show_countdown'] ) ? 1 : 0;
    $settings['countdown_date'] = sanitize_text_field( $_POST['countdown_date'] ?? '' );
    $settings['custom_css']     = wp_strip_all_tags( $_POST['custom_css'] ?? '' );

    update_option( 'nrw_mm_settings', $settings );
    wp_send_json_success( [ 'message' => 'Settings saved!' ] );
}

/* ============================================================
   UPLOAD CUSTOM HTML (AJAX)
   ============================================================ */

add_action( 'wp_ajax_nrw_mm_upload_html', 'nrw_mm_ajax_upload' );

function nrw_mm_ajax_upload() {
    check_ajax_referer( 'nrw_mm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden', 403 );

    if ( empty( $_FILES['html_file'] ) ) {
        wp_send_json_error( [ 'message' => 'No file received.' ] );
    }

    $file    = $_FILES['html_file'];
    $ext     = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
    $allowed = [ 'html', 'htm' ];

    if ( ! in_array( $ext, $allowed ) ) {
        wp_send_json_error( [ 'message' => 'Only .html and .htm files are allowed.' ] );
    }

    if ( ! file_exists( NRW_MM_UPLOAD_DIR ) ) {
        wp_mkdir_p( NRW_MM_UPLOAD_DIR );
    }

    $filename = 'maintenance-custom.' . $ext;
    $dest     = NRW_MM_UPLOAD_DIR . $filename;

    if ( move_uploaded_file( $file['tmp_name'], $dest ) ) {
        $settings = nrw_mm_get_settings();
        $settings['custom_html_file'] = $filename;
        update_option( 'nrw_mm_settings', $settings );
        wp_send_json_success( [ 'message' => 'HTML uploaded successfully!', 'filename' => $filename ] );
    } else {
        wp_send_json_error( [ 'message' => 'Upload failed. Check folder permissions.' ] );
    }
}

/* ============================================================
   ADMIN PAGE
   ============================================================ */

function nrw_mm_admin_page() {
    $s = nrw_mm_get_settings();
    include NRW_MM_PLUGIN_DIR . 'templates/admin-page.php';
}

=== NRW Maintenance Mode ===
Contributors: nrwone
Tags: maintenance, maintenance mode, coming soon, under construction, SEO safe
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A beautiful, SEO-safe maintenance mode plugin. Upload custom HTML or pick from 3 polished built-in themes. Admins always see the live site.

== Description ==

**NRW Maintenance Mode** is a lightweight, developer-friendly maintenance mode plugin that is:

* **SEO Safe** — sends `503 Service Unavailable` + `Retry-After` headers so search engines don't penalize you
* **Plugin Safe** — uses `template_redirect` hook, never touches core files
* **Beautiful** — three hand-crafted built-in themes (Modern, Minimal, Bold)
* **Custom HTML** — upload your own `.html` file and use it as the maintenance page
* **Admin Bypass** — logged-in admins see the live site even when maintenance is on
* **No residue** — settings are preserved; toggling off restores your site exactly as it was

== Installation ==

1. Upload the `nrw-maintenance-mode` folder to `/wp-content/plugins/`
2. Activate the plugin through the **Plugins** menu in WordPress
3. Go to **Maintenance Mode** in the admin sidebar
4. Customize your page and toggle maintenance mode on

== Frequently Asked Questions ==

= Will this affect my SEO? =
No. When maintenance mode is active, the plugin sends a proper 503 status code with a Retry-After header. Search engines treat this as a temporary outage and will not penalize your rankings.

= Can I see my site while maintenance is on? =
Yes. Enable "Admins can see the site" in Settings and logged-in administrators will bypass the maintenance page.

= What happens when I turn off maintenance mode? =
Your site returns to normal immediately. All plugins, themes, and content are unaffected — the plugin only intercepts the frontend output.

= Can I use my own design? =
Yes! Upload any `.html` file in the Custom HTML tab and select "Use Custom HTML."

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release.
